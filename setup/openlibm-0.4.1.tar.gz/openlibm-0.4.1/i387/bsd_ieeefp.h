#include "include/cdefs-compat.h"
#include "amd64/bsd_ieeefp.h"