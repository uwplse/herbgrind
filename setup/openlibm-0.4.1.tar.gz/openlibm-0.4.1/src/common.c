#include "math_private.h"
DLLEXPORT int isopenlibm() {
    return 1;
}
